        <!-- Final do Container para abrigar os conteúdos das páginas do sistema -->
        </div>

        <!-- Container para abrigar o rodapé do sistema -->
        <div class="container-fluid text-center bg-dark text-light p-2 fixed-bottom">
            Sistema desenvolvido nas aulas de Programação Web I do IFPR Telêmaco Borba
        </div>  

    </body>
</html>